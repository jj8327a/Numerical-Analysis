import PIL
from PIL import Image


def conversion(string):
    plaintext = list(string.split())
    return plaintext


def color_change():
    for x in range(0, width):
        for y in range(0, height):
            old_color = list(ori_image.getpixel((x, y)))
            old_color[0] = old_color[0] + 4
            old_color[1] = old_color[1] + 3
            old_color[2] = old_color[2] + 0
            img.putpixel((x, y), tuple(old_color))
    return tuple(old_color)


def rsaencrypt(p, n, e):
    t = p ** e // n
    q = p ** e - t * n
    return q

def rsadecrypt(c, n, d):
    b = c**d//n
    r = c**d-b*n
    return r


def mea(c, n, d):
    b = c*d//n
    r = c*d-b*n
    return r


def inverse():
    for i in range(0, (p-1)*(q-1)):
        if mea(sum(difference), (p-1)*(q-1), i) == 1:
            return i
        else:
            pass


def program(p,q):
    print("Please select")
    print("Encode: 1")
    print("Decode: 2")
    z = int(input())
    global ori_image
    global width, height
    global img
    global difference
    if z == 1:
        print("Picture File")
        file = input()
        mess = conversion(input("Numerical Plaintext:"))
        print("Encrypting...")
        text = []
        for i in range(0, len(mess)):
            text.append(int(mess[i]))
        plain = []
        for i in text:
            plain.append(rsaencrypt(i, p*q, 7))

        print("Ciphertext:", plain)

        ori_image = PIL.Image.open(file)
        width, height = ori_image.size
        img = PIL.Image.new(ori_image.mode, ori_image.size)

        color_change()

        img.save("message.png")


    elif z == 2:
        text = (conversion((input("Enter Ciphertext:"))))
        original = input("1st File:")
        second = input("2nd File:")
        pic1 = PIL.Image.open(original)
        pic2 = PIL.Image.open(second)
        print("Decoding...")
        cipher = []
        for i in range(0, len(text)):
            cipher.append(int(text[i]))

        rgb_pixel_value1 = pic1.convert("RGB")
        rgb_pixel_value2 = rgb_pixel_value1.getpixel((12, 12))
        rgb_pixel_value3 = pic2.convert("RGB")
        rgb_pixel_value4 = rgb_pixel_value3.getpixel((12, 12))

        list1 = list(rgb_pixel_value2)
        list2 = list(rgb_pixel_value4)
        difference = []

        zip_object = zip(list1, list2)
        for list1_i, list2_i in zip_object:
            difference.append(abs(list2_i - list1_i))
        numplain = []

        for i in cipher:
            numplain.append(rsadecrypt(i, p*q, inverse()))

        print("Decrypted Message: ", numplain)
    else:
        pass

p= int(input("Prime 1:"))
q= int(input("Prime 2:"))
program(p,q)
